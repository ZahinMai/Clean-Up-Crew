from controller import Robot
import math, os, sys
from collections import deque

THIS_DIR = os.path.dirname(__file__)
CTRL_DIR = os.path.dirname(THIS_DIR)
if CTRL_DIR not in sys.path:
    sys.path.append(CTRL_DIR)

from lib_shared.local_planner import DWA

LEFT_MOTOR = 'left wheel motor'
RIGHT_MOTOR = 'right wheel motor'
LIDAR_NAME = 'LDS-01'
IMU_NAME = 'inertial unit'
COMPASS_NAME = 'compass'
GPS_NAME = 'gps'

WHEEL_RADIUS = 0.033
AXLE_LENGTH = 0.160

def get_device(robot, name):
    try:
        return robot.getDevice(name)
    except:
        return None

def get_yaw(imu, compass):
    if imu:
        r, p, y = imu.getRollPitchYaw()
        return y
    if compass:
        n = compass.getValues()
        return math.atan2(n[0], n[2])
    return 0.0

def world_to_robot(dx, dz, yaw):
    gx = dx * math.cos(-yaw) - dz * math.sin(-yaw)
    gy = dx * math.sin(-yaw) + dz * math.cos(-yaw)
    return gx, gy

def main():
    robot = Robot()
    ts = int(robot.getBasicTimeStep())

    lm = get_device(robot, LEFT_MOTOR)
    rm = get_device(robot, RIGHT_MOTOR)
    lm.setPosition(float('inf'))
    rm.setPosition(float('inf'))
    lm.setVelocity(0.0)
    rm.setVelocity(0.0)

    imu = get_device(robot, IMU_NAME)
    if imu: imu.enable(ts)
    compass = get_device(robot, COMPASS_NAME)
    if compass: compass.enable(ts)
    gps = get_device(robot, GPS_NAME); gps.enable(ts)
    lidar = get_device(robot, LIDAR_NAME); lidar.enable(ts)

    dwa = DWA({
        "V_MAX": 0.25,
        "SAFE": 0.10,
        "CLEAR_N": 1.00,
        "GAMMA": 0.50,
        "BETA": 0.35,
        "ALPHA": 0.30,
        "EPS": 0.10
    })

    prev = (0.0, 0.0)
    SMOOTH = 0.6

    SPEED_WINDOW = deque(maxlen=20)
    AVG_THRESHOLD = 0.02
    last_unstuck = -10.0
    UNSTUCK_COOLDOWN = 1.5

    WAYPOINTS = [
        (0.90, 0.00),
        (0.90, 0.90),
        (-0.80, 0.90),
        (-0.80, 0.00),
    ]
    wp_i = 0

    while robot.step(ts) != -1:
        x, _, z = gps.getValues()
        yaw = get_yaw(imu, compass)

        tx, tz = WAYPOINTS[wp_i]
        dx, dz = (tx - x), (tz - z)
        if math.hypot(dx, dz) < 0.18:
            wp_i = (wp_i + 1) % len(WAYPOINTS)
            continue

        ranges = lidar.getRangeImage()
        hfov = lidar.getFov()
        nscan = lidar.getHorizontalResolution()
        obs = []
        for i, r in enumerate(ranges):
            if r == float('inf') or r <= 0.03:
                continue
            a = -hfov/2 + hfov * (i / (nscan - 1))
            obs.append((r * math.cos(a), r * math.sin(a)))

        gx, gy = world_to_robot(dx, dz, yaw)

        v, w = dwa.get_safe_velocities(obs, (gx, gy), prev_cmd=prev, cur=prev)

        v = SMOOTH * prev[0] + (1.0 - SMOOTH) * v
        w = SMOOTH * prev[1] + (1.0 - SMOOTH) * w
        prev = (v, w)

        SPEED_WINDOW.append(abs(v))
        now = robot.getTime()
        stuck = (len(SPEED_WINDOW) == SPEED_WINDOW.maxlen and
                 sum(SPEED_WINDOW) / len(SPEED_WINDOW) < AVG_THRESHOLD)

        if stuck and (now - last_unstuck) > UNSTUCK_COOLDOWN:
            v = 0.0
            w = 0.5
            prev = (v, w)
            last_unstuck = now

        wl = (v - 0.5 * w * AXLE_LENGTH) / WHEEL_RADIUS
        wr = (v + 0.5 * w * AXLE_LENGTH) / WHEEL_RADIUS

        max_w = min(lm.getMaxVelocity(), rm.getMaxVelocity())
        wl = max(-max_w, min(max_w, wl))
        wr = max(-max_w, min(max_w, wr))

        lm.setVelocity(wl)
        rm.setVelocity(wr)

        if int(robot.getTime()) % 1 == 0:
            print(f"[DWA] wp={wp_i} v={v:.2f} w={w:.2f} wl={wl:.2f} wr={wr:.2f} obs={len(obs)}")

if __name__ == "__main__":
    main()
