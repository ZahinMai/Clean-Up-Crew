from __future__ import annotations
from typing import List, Tuple, Dict
import math

DEFAULTS: Dict[str, float] = dict(
    DT_CTRL=0.08,
    T_PRED=2.0,
    DT_SIM=0.08,
    NV=10,
    NW=16,
    V_MAX=0.25,
    W_MAX=2.0,
    A_V=1.0,
    A_W=2.5,
    RADIUS=0.18,
    SAFE=0.10,
    CLEAR_N=1.00,
    ALPHA=0.30,
    BETA=0.35,
    GAMMA=0.50,
    DELTA=0.10,
    EPS=0.10,
    D_NORM=2.0
)

def _clamp(x, a, b): return a if x < a else b if x > b else x

def _ang(a: float) -> float:
    while a > math.pi: a -= 2 * math.pi
    while a <= -math.pi: a += 2 * math.pi
    return a

class DWA:
    def __init__(self, params: Dict | None = None):
        p = dict(DEFAULTS)
        if params: p.update(params)
        self.p = p

    def rollout(self, v: float, w: float) -> List[Tuple[float, float, float]]:
        x = y = th = t = 0.0
        traj: List[Tuple[float, float, float]] = []
        while t < self.p['T_PRED']:
            x += v * math.cos(th) * self.p['DT_SIM']
            y += v * math.sin(th) * self.p['DT_SIM']
            th = _ang(th + w * self.p['DT_SIM'])
            traj.append((x, y, th))
            t += self.p['DT_SIM']
        return traj

    @staticmethod
    def _min_clear(traj_xy: List[Tuple[float, float]], obs_xy: List[Tuple[float, float]]) -> float:
        if not obs_xy:
            return float('inf')
        dmin = float('inf')
        for tx, ty in traj_xy:
            for ox, oy in obs_xy:
                d = math.hypot(ox - tx, oy - ty)
                if d < dmin:
                    dmin = d
        return dmin

    def get_safe_velocities(
        self,
        lidar_points: List[Tuple[float, float]],
        goal_vec: Tuple[float, float],
        prev_cmd: Tuple[float, float] = (0.0, 0.0),
        cur: Tuple[float, float] = (0.0, 0.0)
    ) -> Tuple[float, float]:
        p = self.p
        vcur, wcur = cur

        Vmin = _clamp(vcur - p['A_V'] * p['DT_CTRL'], -p['V_MAX'], p['V_MAX'])
        Vmax = _clamp(vcur + p['A_V'] * p['DT_CTRL'], -p['V_MAX'], p['V_MAX'])
        Wmin = _clamp(wcur - p['A_W'] * p['DT_CTRL'], -p['W_MAX'], p['W_MAX'])
        Wmax = _clamp(wcur + p['A_W'] * p['DT_CTRL'], -p['W_MAX'], p['W_MAX'])

        samples: List[Tuple[float, float]] = [prev_cmd, (0.0, 0.0)]
        if p['W_MAX'] > 0.0:
            samples += [(0.0, 0.7 * p['W_MAX']), (0.0, -0.7 * p['W_MAX'])]

        for i in range(max(1, p['NV'])):
            vv = Vmin + (Vmax - Vmin) * (i / (p['NV'] - 1 if p['NV'] > 1 else 1))
            for j in range(max(1, p['NW'])):
                ww = Wmin + (Wmax - Wmin) * (j / (p['NW'] - 1 if p['NW'] > 1 else 1))
                samples.append((vv, ww))

        gx, gy = goal_vec
        gtheta = math.atan2(gy, gx) if (gx * gx + gy * gy) > 1e-9 else 0.0

        best = (0.0, 0.0)
        bestJ = -1e9

        for v, w in samples:
            traj = self.rollout(v, w)
            pts = [(x, y) for (x, y, _) in traj]

            dmin_raw = self._min_clear(pts, lidar_points)
            eff_clear = max(0.0, dmin_raw - (p['RADIUS'] + 0.02))

            if eff_clear < p['SAFE']:
                continue

            xE, yE, thE = traj[-1]

            H = 1.0 - abs(_ang(thE - gtheta)) / math.pi
            Pp = 1.0 - min(math.hypot(gx - xE, gy - yE) / p['D_NORM'], 1.0)
            Vt = max(0.0, v) / (p['V_MAX'] if p['V_MAX'] > 0 else 1.0)
            C = min(eff_clear / p['CLEAR_N'], 1.0)
            S = math.exp(-math.hypot(v - prev_cmd[0], w - prev_cmd[1]) / 0.2)

            J = p['ALPHA'] * H + p['BETA'] * Pp + p['GAMMA'] * C + p['DELTA'] * Vt + p['EPS'] * S
            if J > bestJ:
                bestJ, best = J, (v, w)

        if bestJ < -1e8:
            if abs(gtheta) > math.pi / 6:
                return (0.0, 0.3 * math.copysign(1.0, gtheta))
            return (0.05, 0.0)

        return best
